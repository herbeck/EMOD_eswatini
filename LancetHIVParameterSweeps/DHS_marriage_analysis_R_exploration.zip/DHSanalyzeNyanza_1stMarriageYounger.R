library(survey)
# library(foreign)
library(readstata13)
library(plotrix)
library(data.table)

#set working directory
homedir<-'C:/Users/kkripke/Dropbox/OPTIONS/ZimPrEP-LSHTM/Kenya/DHS marriage analysis'
setwd(homedir)

#KenyaDHS2014_women  <- read.dta("C:\\Users\\kkripke\\Documents\\survey data\\KE_2014_DHS_microdata\\keir70dt\\KEIR70FL.DTA",convert.factors=FALSE)
#rm(KenyaDHS2014_women)

KenyaDHS2014_couples  <- read.dta13('KE_2014_DHS_microdata/kecr70dt/KECR70FL.DTA')
Nyanza2014 <- subset(KenyaDHS2014_couples, sregion=="homa bay" | sregion == "kisumu" | sregion == "kisii" | sregion == "nyamira" | sregion == "migori")
CurrentSinglePartnerships2014 <- subset(Nyanza2014, v503=="once" & mv503=="once" & v505==0 & mv505==1 & v012<40 & mv012<45)

# CurrentSinglePartnerships2014 - 345 observations (was 420 before restricting age to below 40 for women and below 45 for men)

# v012, mv012: respondent's current age in years
# 
# V502 Whether the respondent is currently, formerly or never married (or lived with a partner).
# Currently married includes married women and women living with a partner, and formerly
# married includes widowed, divorced, separated women and women who have lived with a
# partner but are not now living with a partner. 

# V503 Whether the respondent has been married or lived with a man once or more than once.
# BASE: Ever-married women (V501 <> 0). 

# MV503 Whether the (male) respondent has been married or lived with a woman once or more than once.
# BASE: Ever-married men (MV501 <> 0). 

# V505 Whether the respondent is in a polygynous union and the number of other wives the respondent's partner currently has. 0 = no other wives. 
# BASE: Currently married or in union women (V502 = 1). 

# MV505 The number of wives the (male) respondent currently has. This is the number of wives and live-in
# partners. BASE: Currently married or in union men (MV502 = 1). 


#table(KenyaDHS2014_couples[,"v503"])
#Have you been married or lived with a man only once or more than once?
#1=only once
#2=more than once


#hist(KenyaDHS2014_couples[,"v506"])
#The rank of the respondent among the partner's wives.
#BASE: Currently married or in union women in a polygynous union (V502 = 1 & V505 > 0). 

rm(KenyaDHS2014_couples)
rm(Nyanza2014)


# plot(CurrentSinglePartnerships2014[,"v511"],CurrentSinglePartnerships2014[,"mv511"])
#v511 is age at first union for females
#mv511 is age at first union for males

# table(CurrentSinglePartnerships2014[,"mv511"],CurrentSinglePartnerships2014[,"v511"])

# ageFirstMarriage <- matrix(c(CurrentSinglePartnerships2014[,"v511"],CurrentSinglePartnerships2014[,"mv511"]),nrow=3869,ncol=2)

# table(ageFirstMarriage[,1],ageFirstMarriage[,2])
# table rows are women and columns are men

# library(grDevices)
# r <- rainbow(9)

##### OPTION 4: kde2d from package 'MASS' #######
# Not a true heatmap as interpolated (kernel density estimation)

# library(MASS)

# Default call 
# k <- kde2d(df$x, df$y)
# image(k, col=r)

# Adjust binning (interpolate - can be computationally intensive for large datasets) 

# k <- kde2d(ageFirstMarriage[,1],ageFirstMarriage[,2], n=200)
# image(k, col=r)


CSP_data <- data.frame("F_age1stMarriage"        = CurrentSinglePartnerships2014$v511,
                       "M_age1stMarriage"  = CurrentSinglePartnerships2014$mv511,
                       "sample.weight"     = CurrentSinglePartnerships2014$mv005/1000000,
                       "cluster"           = CurrentSinglePartnerships2014$mv021,
                       "household"         = CurrentSinglePartnerships2014$mv002
)

rm(CurrentSinglePartnerships2014)

KenyaDHS2008_couples  <- read.dta13('KE_2008-09_DHS_microdata/kecr52dt/KECR52FL.DTA')
Nyanza2008 <- subset(KenyaDHS2008_couples, v023=="nyanza")
CurrentSinglePartnerships2008 <- subset(Nyanza2008, v503==1 & mv503=="once" & v505==0 & mv505==1 & v012<40 & mv012<45)

# CurrentSinglePartnerships2008 - - 116 observations (was 137 before restricting age to below 40 for women and below 45 for men)

rm(KenyaDHS2008_couples)
rm(Nyanza2008)

CSP_data <- data.frame("F_age1stMarriage"        = c(CSP_data$F_age1stMarriage,CurrentSinglePartnerships2008$v511),
                        "M_age1stMarriage"  = c(CSP_data$M_age1stMarriage,CurrentSinglePartnerships2008$mv511),
                        "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnerships2008$mv005/1000000),
                        "cluster"           = c(CSP_data$cluster,CurrentSinglePartnerships2008$mv021),
                        "household"         = c(CSP_data$household,CurrentSinglePartnerships2008$mv002)
)

rm(CurrentSinglePartnerships2008)



KenyaDHS2003_couples  <- read.dta13('KE_2003_DHS_microdata/kecr42dt/KECR42FL.DTA')
Nyanza2003 <- subset(KenyaDHS2003_couples, v023=="nyanza")
CurrentSinglePartnerships2003 <- subset(Nyanza2003, v503=="once" & mv503==1 & v505==0 & mv505==1 & v012<40 & mv012<45)

# CurrentSinglePartnerships2003 - - 91 observations (was 118 before restricting age to below 40 for women and below 45 for men)


rm(KenyaDHS2003_couples)
rm(Nyanza2003)

CSP_data <- data.frame("F_age1stMarriage"        = c(CSP_data$F_age1stMarriage,CurrentSinglePartnerships2003$v511),
                        "M_age1stMarriage"  = c(CSP_data$M_age1stMarriage,CurrentSinglePartnerships2003$mv511),
                        "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnerships2003$mv005/1000000),
                        "cluster"           = c(CSP_data$cluster,CurrentSinglePartnerships2003$mv021),
                        "household"         = c(CSP_data$household,CurrentSinglePartnerships2003$mv002)
)

rm(CurrentSinglePartnerships2003)


KenyaDHS1998_couples  <- read.dta13('KE_1998_DHS_microdata/kecr3adt/KECR3aFL.DTA')
Nyanza1998 <- subset(KenyaDHS1998_couples, v024=="nyanza")
CurrentSinglePartnerships1998 <- subset(Nyanza1998, v503=="once" & mv503=="once" & v505==0 & mv505==1 & v012<40 & mv012<45)

# CurrentSinglePartnerships1998 - - 98 observations (was 130 before restricting age to below 40 for women and below 45 for men)

rm(KenyaDHS1998_couples)
rm(Nyanza1998)

CSP_data <- data.frame("F_age1stMarriage"        = c(CSP_data$F_age1stMarriage,CurrentSinglePartnerships1998$v511),
                       "M_age1stMarriage"  = c(CSP_data$M_age1stMarriage,CurrentSinglePartnerships1998$mv511),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnerships1998$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnerships1998$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnerships1998$mv002)
)

rm(CurrentSinglePartnerships1998)


KenyaDHS1993_couples  <- read.dta13('KE_1993_DHS_microdata/kecr32dt/KECR32FL.DTA')
Nyanza1993 <- subset(KenyaDHS1993_couples, v024=="nyanza")
CurrentSinglePartnerships1993 <- subset(Nyanza1993, v503=="once" & mv503=="once" & v505==0 & mv505==1 & v012<40 & mv012<45)

# CurrentSinglePartnerships1993 - - 90 observations (was 113 before restricting age to below 40 for women and below 45 for men)

rm(KenyaDHS1993_couples)
rm(Nyanza1993)

CSP_data <- data.frame("F_age1stMarriage"        = c(CSP_data$F_age1stMarriage,CurrentSinglePartnerships1993$v511),
                       "M_age1stMarriage"  = c(CSP_data$M_age1stMarriage,CurrentSinglePartnerships1993$mv511),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnerships1993$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnerships1993$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnerships1993$mv002)
)

rm(CurrentSinglePartnerships1993)


# load('.Rdata')


# create survey data frame

CSP_design <- svydesign(ids = ~cluster + household, weights = ~sample.weight, data = CSP_data, variables=NULL)
# create survey design object

cont_tbl <- svytable(~F_age1stMarriage+M_age1stMarriage, CSP_design, Ntotal = 1, round = FALSE)
# create contingency table using survey weights

plot(cont_tbl)

fwrite(data.frame(cont_tbl), file = "MFAge1stMarriageNyanza_younger.csv",row.names=TRUE)



