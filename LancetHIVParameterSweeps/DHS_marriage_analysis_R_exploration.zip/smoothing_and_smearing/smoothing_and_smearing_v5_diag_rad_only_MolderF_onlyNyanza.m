clear;clc;

inc_1st_marriages_raw = csvread('..\Nyanza_MFAge1stMarriage_age6thru46_padded_Mcol_Frow.csv');
starting_age_M = 7;
starting_age_F = 7;
num_ages = length(inc_1st_marriages_raw);

% group 1-year categories into 2-year categories
num_groups_from_DHSdata = (num_ages-1)/2;

inc_1st_marriages_2yr_bins = nan(num_groups_from_DHSdata,num_groups_from_DHSdata);

for F_iter = 1:num_groups_from_DHSdata
    for M_iter = 1:num_groups_from_DHSdata
        
        inc_1st_marriages_2yr_bins(F_iter, M_iter) = ...
            inc_1st_marriages_raw(2*F_iter-1, 2*M_iter-1) + ...
            inc_1st_marriages_raw(2*F_iter-1, 2*M_iter) + ...
            inc_1st_marriages_raw(2*F_iter,   2*M_iter-1) + ...
            inc_1st_marriages_raw(2*F_iter,   2*M_iter);
        
    end
end

% pad up data up to the age at which we want to stratify partner age
% preference. anyone older than the last bin edge will be grouped into one
% giant bin with equal preference for anyone over that age, e.g., 55+

pad_up_to_age = 55;
last_available_age_of_data = starting_age_F + num_groups_from_DHSdata*2 - 2;
number_of_bins_to_pad = (pad_up_to_age - last_available_age_of_data)/2;
num_groups_after_smear = num_groups_from_DHSdata + number_of_bins_to_pad;

%[X,Y]       = meshgrid(starting_age_M:2:starting_age_F + num_groups_from_DHSdata*2 - 2,starting_age_F:2:starting_age_F + num_groups_from_DHSdata*2 - 2);
[X,Y] = meshgrid(starting_age_M:2:pad_up_to_age,starting_age_F:2:pad_up_to_age);

% pad DHS data with zeros for additional age groups where questionnaire didn't reach
inc_1st_marriages_2yr_bins(end+number_of_bins_to_pad,end+number_of_bins_to_pad)=0;

% smooth out noise

mu = [0 0];
Sigma = 0.03*[1,0;0,1];
x = -1:.2:1;[X1,X2] = meshgrid(x,x);
blur_2yr_filter = mvnpdf([X1(:) X2(:)],mu,Sigma);
blur_2yr_filter = reshape(blur_2yr_filter,length(x),length(x));
%surf(x,x,blur_2yr_filter);
inc_1st_marriages_smoothed = filter2(blur_2yr_filter,inc_1st_marriages_2yr_bins);

figure(1); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_2yr_bins,'EdgeColor','none')
title('Nyanza Age at First Marriages, 1993-2014 DHS Surveys')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

figure(2); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Nyanza Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

csvwrite('MFAge1stMarriage_2yrBins_Smoothed.csv', inc_1st_marriages_smoothed);

% forward smear with exponential with rate parameter R

%Step 1: diagonal smear
R1 = 0.3; % exponential decay rate per 2-year age bin

aggregated_smeared_diagonally = zeros(num_groups_after_smear,num_groups_after_smear);

for F_iter = 1:num_groups_after_smear
    for M_iter = 1:num_groups_after_smear
        
        individual_point_smeared = zeros(num_groups_after_smear,num_groups_after_smear);
        curr_value = inc_1st_marriages_2yr_bins(F_iter, M_iter);
        
        
        for steps_up_the_diagonal = 0:min(num_groups_after_smear-F_iter, num_groups_after_smear-M_iter)
            
            % only move up the diagonal
            F_iter2 = F_iter+steps_up_the_diagonal;
            M_iter2 = M_iter+steps_up_the_diagonal;
            
            F_distance   = F_iter2 - F_iter;
            M_distance   = M_iter2 - M_iter;
            
            tot_distance = sqrt(F_distance^2 + M_distance^2);
            individual_point_smeared(F_iter2, M_iter2) = curr_value * exp(-R1*tot_distance);
            
            
        end
        aggregated_smeared_diagonally = aggregated_smeared_diagonally + individual_point_smeared;
    end
end


% Step 2: radial smear, only in the direction of older males
R2 = 0.5; % exponential decay rate per 2-year age bin

aggregated_smeared_series = zeros(num_groups_after_smear,num_groups_after_smear);

for F_iter = 1:num_groups_after_smear
    for M_iter = 1:num_groups_after_smear
        
        individual_point_smeared = zeros(num_groups_after_smear,num_groups_after_smear);
        curr_value = aggregated_smeared_diagonally(F_iter, M_iter);
        
        for F_iter2 = F_iter:num_groups_after_smear
            for M_iter2 = M_iter:num_groups_after_smear
                
                if F_iter2 > M_iter2
                    %skip
                else
                    
                    F_distance   = F_iter2 - F_iter;
                    M_distance   = M_iter2 - M_iter;
                    
                    % this approach would have smeared equally up, down, and
                    % diagonally, accoeding to distance from the point
                    tot_distance = sqrt(F_distance^2 + M_distance^2);
                    individual_point_smeared(F_iter2, M_iter2) = curr_value * exp(-R2*tot_distance);
                end
            end
        end
        aggregated_smeared_series = aggregated_smeared_series + individual_point_smeared;
    end
end


figure(3); clf; set(gcf,'color','w')
surf(X,Y,aggregated_smeared_series,'EdgeColor','none')
title(['Marriages in Nyanza, Smeared with R1 = ',num2str(R1), ', R2 = ',num2str(R2)])
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

csvwrite('Nyanza_MFAge1stMarriage_2yrBins_Smoothed_Smeared_v5.csv', aggregated_smeared_series);

