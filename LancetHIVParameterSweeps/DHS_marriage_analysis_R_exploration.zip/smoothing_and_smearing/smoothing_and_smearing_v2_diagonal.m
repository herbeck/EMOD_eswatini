clear;clc;

inc_1st_marriages_raw_headers = csvread('..\MFAgeAtMarriage_age6thru53_padded_Mcol_Frow.csv');
[nrow,ncol] = size(inc_1st_marriages_raw_headers)
inc_1st_marriages_raw = inc_1st_marriages_raw_headers(2:nrow,2:ncol)
starting_age_M = 7;
starting_age_F = 7;
num_agesM = ncol - 1;
num_agesF = nrow - 1;

% group 1-year categories into 2-year categories
num_groups_from_DHSdata = (num_agesM)/2;

inc_1st_marriages_2yr_bins = nan(num_groups_from_DHSdata,num_groups_from_DHSdata);

for F_iter = 1:num_groups_from_DHSdata
    for M_iter = 1:num_groups_from_DHSdata
        
        inc_1st_marriages_2yr_bins(F_iter, M_iter) = ...
            inc_1st_marriages_raw(2*F_iter-1, 2*M_iter-1) + ...
            inc_1st_marriages_raw(2*F_iter-1, 2*M_iter) + ...
            inc_1st_marriages_raw(2*F_iter,   2*M_iter-1) + ...
            inc_1st_marriages_raw(2*F_iter,   2*M_iter);
        
    end
end


% fill in NaNs

inc_1st_marriages_2yr_bins((num_agesF/2 + 1):(num_agesM/2),:) = 0;

% pad up data up to the age at which we want to stratify partner age
% preference. anyone older than the last bin edge will be grouped into one
% giant bin with equal preference for anyone over that age, e.g., 55+

pad_up_to_age = 55;
last_available_age_of_data = starting_age_M + num_agesM - 2;
number_of_bins_to_pad = (pad_up_to_age - last_available_age_of_data)/2;
num_groups_after_smear = num_groups_from_DHSdata + number_of_bins_to_pad;

%[X,Y]       = meshgrid(starting_age_M:2:starting_age_F + num_groups_from_DHSdata*2 - 2,starting_age_F:2:starting_age_F + num_groups_from_DHSdata*2 - 2);
[X,Y] = meshgrid(starting_age_M:2:starting_age_F + num_groups_after_smear*2  - 2,starting_age_F:2:starting_age_F + num_groups_after_smear*2  - 2);

% pad DHS data with zeros for additional age groups where questionnaire didn't reach
inc_1st_marriages_2yr_bins(end+5,end+5)=0;

% smooth out noise

mu = [0 0];
Sigma = 0.03*[1,0;0,1];
x = -1:.2:1;
[X1,X2] = meshgrid(x,x);
%blur_2yr_filter = mvnpdf([X1(:) X2(:)],mu,Sigma);
%requires Statistics and Machine Learning Toolbox
blur_2yr_filter = csvread('..\blur_2yr_filter.csv');
blur_2yr_filter2 = reshape(blur_2yr_filter,length(x),length(x));
%surf(x,x,blur_2yr_filter);
inc_1st_marriages_smoothed = filter2(blur_2yr_filter,inc_1st_marriages_2yr_bins);

figure(1); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

csvwrite('MFAge1stMarriage_2yrBins_Smoothed.csv', inc_1st_marriages_smoothed);

% forward smear with exponential with rate parameter R

R = 0.3;

aggregated_smeared = zeros(num_groups_after_smear,num_groups_after_smear);

for F_iter = 1:num_groups_after_smear
    for M_iter = 1:num_groups_after_smear
        
        individual_point_smeared = zeros(num_groups_after_smear,num_groups_after_smear);
        curr_value = inc_1st_marriages_2yr_bins(F_iter, M_iter);
        
        
        for steps_up_the_diagonal = 0:min(num_groups_after_smear-F_iter, num_groups_after_smear-M_iter)
            
            % only move up the diagonal
            F_iter2 = F_iter+steps_up_the_diagonal;
            M_iter2 = M_iter+steps_up_the_diagonal;
            
            F_distance   = F_iter2 - F_iter;
            M_distance   = M_iter2 - M_iter;
            
            tot_distance = sqrt(F_distance^2 + M_distance^2);
            individual_point_smeared(F_iter2, M_iter2) = curr_value * exp(-R*tot_distance);
            
            
        end
        aggregated_smeared = aggregated_smeared + individual_point_smeared;
    end
end

figure(2); clf; set(gcf,'color','w')
surf(X,Y,aggregated_smeared,'EdgeColor','none')
title(['Marriages in Kenya, Newlyweds Smeared with R = ',num2str(R)])
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

csvwrite('MFAge1stMarriage_2yrBins_Smoothed_Smeared_v1_radial_distance_R025.csv', aggregated_smeared);

