inc_1st_marriages_raw = csvread('..\MFAge1stMarriage_age6thru46_padded_Mcol_Frow.csv');
[X,Y] = meshgrid(6:46,6:46);

% reduce from 1-year bins to 2-year bins in 2D

inc_1st_marriages_2yr_bins = nan((length(X)-1)/2,(length(X)-1)/2);


for F_iter = 1:(length(X)-1)/2
    for M_iter = 1:(length(X)-1)/2
        
        inc_1st_marriages_2yr_bins(F_iter, M_iter) = ...
            inc_1st_marriages_raw(2*F_iter-1, 2*M_iter-1) + ...
            inc_1st_marriages_raw(2*F_iter-1, 2*M_iter) + ...
            inc_1st_marriages_raw(2*F_iter,   2*M_iter-1) + ...
            inc_1st_marriages_raw(2*F_iter,   2*M_iter);
            
    
    end
end

inc_1st_marriages = inc_1st_marriages_2yr_bins;
[X,Y] = meshgrid(7:2:45,7:2:45);

% plot raw data before smoothing

figure(101); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])


% try different filters

simplest_filter = 1/9*ones(3);
inc_1st_marriages_smoothed = filter2(simplest_filter,inc_1st_marriages);

   
figure(102); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])


hump_filter = 1/10*ones(3);
hump_filter(2,2) = .2;
inc_1st_marriages_smoothed = filter2(hump_filter,inc_1st_marriages);

   
figure(103); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

wider_hump_filter = [...
    1,4,7,4,1;
    4,16,26,16,4;
    7,26,41,26,7;
    4,16,26,16,4;
    1,4,7,4,1;
    ]*(1/273);
inc_1st_marriages_smoothed = filter2(wider_hump_filter,inc_1st_marriages);

   
figure(104); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

blurrier_hump_filter = [...
    1,4,6,4,1;
    4,16,24,16,4;
    7,24,36,24,7;
    4,16,24,16,4;
    1,4,6,4,1;
    ]*(1/256);
inc_1st_marriages_smoothed = filter2(blurrier_hump_filter,inc_1st_marriages);
   
figure(105); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])



mu = [0 0];
Sigma = 0.025*[1,0;0,1];
x = -1:.1:1;[X1,X2] = meshgrid(x,x);
blurriest_filter = mvnpdf([X1(:) X2(:)],mu,Sigma);
blurriest_filter = reshape(blurriest_filter,length(x),length(x));
surf(x,x,F);
inc_1st_marriages_smoothed = filter2(blurriest_filter,inc_1st_marriages);
% this one is good for two-year age bins

figure(106); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])


mu = [0 0];
Sigma = 0.03*[1,0;0,1];
x = -1:.2:1;[X1,X2] = meshgrid(x,x);
blur_2yr_filter = mvnpdf([X1(:) X2(:)],mu,Sigma);
blur_2yr_filter = reshape(blur_2yr_filter,length(x),length(x));
surf(x,x,blur_2yr_filter);
inc_1st_marriages_smoothed = filter2(blur_2yr_filter,inc_1st_marriages);
% this one is good for two-year age bins

figure(107); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Newlyweds in Kenya, Age at First Marriages, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])


