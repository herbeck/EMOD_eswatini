clear;clc;

inc_1st_marriages_raw = csvread('MFAgeAtMarriage_age7thru48M_54F_padded_Mcol_Frow.csv');
starting_age_M = 7;
starting_age_F = 7;
num_ages_M = size(inc_1st_marriages_raw,1);
num_ages_F = size(inc_1st_marriages_raw,2);


% group 1-year categories into 2-year categories
num_groups_from_DHSdata = (num_ages_F)/2;

inc_1st_marriages_2yr_bins = nan((num_ages_M)/2,(num_ages_F)/2);

for F_iter = 1:(num_ages_F)/2
    for M_iter = 1:(num_ages_M)/2
        
        inc_1st_marriages_2yr_bins(M_iter, F_iter) = ...
            inc_1st_marriages_raw(2*M_iter-1, 2*F_iter-1) + ...
            inc_1st_marriages_raw(2*M_iter-1, 2*F_iter) + ...
            inc_1st_marriages_raw(2*M_iter,   2*F_iter-1) + ...
            inc_1st_marriages_raw(2*M_iter,   2*F_iter);
        
    end
end

% pad up data up to the age at which we want to stratify partner age
% preference. anyone older than the last bin edge will be grouped into one
% giant bin with equal preference for anyone over that age, e.g., 55+

pad_up_to_age = 54;
last_available_age_of_data_F = starting_age_F + num_ages_F - 1;
number_of_bins_to_pad_F = (pad_up_to_age - last_available_age_of_data_F)/2;

last_available_age_of_data_M = starting_age_M + num_ages_M - 1;
number_of_bins_to_pad_M = (pad_up_to_age - last_available_age_of_data_M)/2;


%[X,Y]       = meshgrid(starting_age_M:2:starting_age_F + num_groups_from_DHSdata*2 - 2,starting_age_F:2:starting_age_F + num_groups_from_DHSdata*2 - 2);
[X,Y] = meshgrid(starting_age_M:2:pad_up_to_age,starting_age_F:2:pad_up_to_age);

% pad DHS data with zeros for additional age groups where questionnaire didn't reach
inc_1st_marriages_2yr_bins(end+number_of_bins_to_pad_M,end+number_of_bins_to_pad_F)=0;

% smooth out noise

mu = [0 0];
Sigma = 0.03*[1,0;0,1];
x = -1:.2:1;[X1,X2] = meshgrid(x,x);
blur_2yr_filter = mvnpdf([X1(:) X2(:)],mu,Sigma);
blur_2yr_filter = reshape(blur_2yr_filter,length(x),length(x));
%surf(x,x,blur_2yr_filter);
inc_1st_marriages_smoothed = filter2(blur_2yr_filter,inc_1st_marriages_2yr_bins);


csvwrite('MFAge1stMarriage_2yrBins_Smoothed_to_validate_R.csv', inc_1st_marriages_smoothed);

figure(1); clf; set(gcf,'color','w')
surf(X,Y,inc_1st_marriages_smoothed,'EdgeColor','none')
title('Marriages in Nyanza, Smoothed')
xlabel('Male Age');
ylabel('Female Age');
view([0,90])

