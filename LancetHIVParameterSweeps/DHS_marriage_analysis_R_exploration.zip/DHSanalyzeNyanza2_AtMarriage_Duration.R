###### this is the final extraction script as of 8/23/2017#######

library(survey)
# library(foreign)
library(readstata13)
library(plotrix)
library(data.table)

#set working directory
homedir<-'C:/Users/kkripke/Dropbox/OPTIONS/ZimPrEP-LSHTM/Kenya/DHS marriage analysis'
setwd(homedir)

#KenyaDHS2014_women  <- read.dta("C:\\Users\\kkripke\\Documents\\survey data\\KE_2014_DHS_microdata\\keir70dt\\KEIR70FL.DTA",convert.factors=FALSE)
#rm(KenyaDHS2014_women)

KenyaDHS2014_couples  <- read.dta13('KE_2014_DHS_microdata/kecr70dt/KECR70FL.DTA')
Nyanza2014 <- subset(KenyaDHS2014_couples, sregion=="homa bay" | sregion == "kisumu" | sregion == "kisii" | sregion == "nyamira" | sregion == "migori")
# Nyanza2014 contains 651 couples
CurrentSinglePartnershipsF2014 <- subset(Nyanza2014, v503=="once")
# currently married women who have only been married once; n=625
CurrentSinglePartnershipsM2014 <- subset(Nyanza2014, mv503=="once" & v503!="once")
# currently married men who have only been married once, but wives have been married more than once; n=12
# CurrentSinglePartnershipsMF2014 <- subset(Nyanza2014, mv503=="once" & v503=="once")
# currently married couples in which both men and women have only been married once; n=430 (subset of CurrentSinglePartnershipsF2014)

# V502 Whether the respondent is currently, formerly or never married (or lived with a partner).
# Currently married includes married women and women living with a partner, and formerly
# married includes widowed, divorced, separated women and women who have lived with a
# partner but are not now living with a partner. 

# V503 Whether the respondent has been married or lived with a man once or more than once.
# BASE: Ever-married women (V501 <> 0). 

# MV503 Whether the (male) respondent has been married or lived with a woman once or more than once.
# BASE: Ever-married men (MV501 <> 0). 

# V505 Whether the respondent is in a polygynous union and the number of other wives the respondent's partner currently has. 0 = no other wives. 
# BASE: Currently married or in union women (V502 = 1). 

# MV505 The number of wives the (male) respondent currently has. This is the number of wives and live-in
# partners. BASE: Currently married or in union men (MV502 = 1). 


#table(KenyaDHS2014_couples[,"v503"])
#Have you been married or lived with a man only once or more than once?
#1=only once
#2=more than once


#hist(KenyaDHS2014_couples[,"v506"])
#The rank of the respondent among the partner's wives.
#BASE: Currently married or in union women in a polygynous union (V502 = 1 & V505 > 0). 

rm(KenyaDHS2014_couples)
rm(Nyanza2014)


# plot(CurrentSinglePartnerships2014[,"v511"],CurrentSinglePartnerships2014[,"mv511"])
# v511 is age at first union for females
# mv511 is age at first union for males

# table(CurrentSinglePartnerships2014[,"mv511"],CurrentSinglePartnerships2014[,"v511"])

# ageFirstMarriage <- matrix(c(CurrentSinglePartnerships2014[,"v511"],CurrentSinglePartnerships2014[,"mv511"]),nrow=3869,ncol=2)

# table(ageFirstMarriage[,1],ageFirstMarriage[,2])
# table rows are women and columns are men

# library(grDevices)
# r <- rainbow(9)

##### OPTION 4: kde2d from package 'MASS' #######
# Not a true heatmap as interpolated (kernel density estimation)

# library(MASS)

# Default call 
# k <- kde2d(df$x, df$y)
# image(k, col=r)

# Adjust binning (interpolate - can be computationally intensive for large datasets) 

# k <- kde2d(ageFirstMarriage[,1],ageFirstMarriage[,2], n=200)
# image(k, col=r)


CSP_data <- data.frame("F_ageAtMarriage"   = CurrentSinglePartnershipsF2014$v511,
                       "M_ageAtMarriage"   = (CurrentSinglePartnershipsF2014$v511 + CurrentSinglePartnershipsF2014$mv012 - CurrentSinglePartnershipsF2014$v012),
                       "F_currentAge"      = CurrentSinglePartnershipsF2014$v012,
                       "M_currentAge"      = CurrentSinglePartnershipsF2014$mv012,
                       "marriageDuration"  = (CurrentSinglePartnershipsF2014$v012 - CurrentSinglePartnershipsF2014$v511),
                       "sample.weight"     = CurrentSinglePartnershipsF2014$mv005/1000000,
                       "cluster"           = CurrentSinglePartnershipsF2014$mv021,
                       "household"         = CurrentSinglePartnershipsF2014$mv002
)

# man's age at time of marriage = woman's age at time of marriage + man's age now - woman's age now
# man's age now mv012
# woman's age now v012

rm(CurrentSinglePartnershipsF2014)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,(CurrentSinglePartnershipsM2014$mv511 + CurrentSinglePartnershipsM2014$v012 - CurrentSinglePartnershipsM2014$mv012)),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,CurrentSinglePartnershipsM2014$mv511),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsM2014$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsM2014$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsM2014$v012 - (CurrentSinglePartnershipsM2014$mv511 + CurrentSinglePartnershipsM2014$v012 - CurrentSinglePartnershipsM2014$mv012))),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsM2014$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsM2014$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsM2014$mv002)
)

# woman's age at time of marriage = man's age at time of marriage + woman's age now - man's age now

rm(CurrentSinglePartnershipsM2014)

KenyaDHS2008_couples  <- read.dta13('KE_2008-09_DHS_microdata/kecr52dt/KECR52FL.DTA')
Nyanza2008 <- subset(KenyaDHS2008_couples, v023=="nyanza")
# Nyanza2008 contains 244 couples
CurrentSinglePartnershipsF2008 <- subset(Nyanza2008, v503==1)
# currently married women who have only been married once; n=228
CurrentSinglePartnershipsM2008 <- subset(Nyanza2008, mv503=="once" & v503!=1)
# currently married men who have only been married once, but wives have been married more than once; n=6
rm(KenyaDHS2008_couples)
rm(Nyanza2008)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,CurrentSinglePartnershipsF2008$v511),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,(CurrentSinglePartnershipsF2008$v511 + CurrentSinglePartnershipsF2008$mv012 - CurrentSinglePartnershipsF2008$v012)),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsF2008$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsF2008$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsF2008$v012 - CurrentSinglePartnershipsF2008$v511)),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsF2008$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsF2008$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsF2008$mv002)
)

rm(CurrentSinglePartnershipsF2008)

CSP_data <- data.frame("F_ageAtMarriage"  = c(CSP_data$F_ageAtMarriage,(CurrentSinglePartnershipsM2008$mv511 + CurrentSinglePartnershipsM2008$v012 - CurrentSinglePartnershipsM2008$mv012)),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,CurrentSinglePartnershipsM2008$mv511),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsM2008$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsM2008$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsM2008$v012 - (CurrentSinglePartnershipsM2008$mv511 + CurrentSinglePartnershipsM2008$v012 - CurrentSinglePartnershipsM2008$mv012))),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsM2008$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsM2008$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsM2008$mv002)
)

rm(CurrentSinglePartnershipsM2008)


KenyaDHS2003_couples  <- read.dta13('KE_2003_DHS_microdata/kecr42dt/KECR42FL.DTA')
Nyanza2003 <- subset(KenyaDHS2003_couples, v023=="nyanza")
# Nyanza2003 contains 184 couples
CurrentSinglePartnershipsF2003 <- subset(Nyanza2003, v503=="once")
# currently married women who have only been married once; n=172
CurrentSinglePartnershipsM2003 <- subset(Nyanza2003, mv503==1 & v503!="once")
# currently married men who have only been married once, but wives have been married more than once; n=4
rm(KenyaDHS2003_couples)
rm(Nyanza2003)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,CurrentSinglePartnershipsF2003$v511),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,(CurrentSinglePartnershipsF2003$v511 + CurrentSinglePartnershipsF2003$mv012 - CurrentSinglePartnershipsF2003$v012)),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsF2003$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsF2003$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsF2003$v012 - CurrentSinglePartnershipsF2003$v511)),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsF2003$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsF2003$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsF2003$mv002)
)

rm(CurrentSinglePartnershipsF2003)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,(CurrentSinglePartnershipsM2003$mv511 + CurrentSinglePartnershipsM2003$v012 - CurrentSinglePartnershipsM2003$mv012)),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,CurrentSinglePartnershipsM2003$mv511),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsM2003$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsM2003$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsM2003$v012 - (CurrentSinglePartnershipsM2003$mv511 + CurrentSinglePartnershipsM2003$v012 - CurrentSinglePartnershipsM2003$mv012))),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsM2003$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsM2003$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsM2003$mv002)
)

rm(CurrentSinglePartnershipsM2003)


KenyaDHS1998_couples  <- read.dta13('KE_1998_DHS_microdata/kecr3adt/KECR3aFL.DTA')
Nyanza1998 <- subset(KenyaDHS1998_couples, v024=="nyanza")
# Nyanza1998 contains 231 couples
CurrentSinglePartnershipsF1998 <- subset(Nyanza1998, v503=="once")
# currently married women who have only been married once; n=221
CurrentSinglePartnershipsM1998 <- subset(Nyanza1998, mv503=="once" & v503!="once")
# currently married men who have only been married once, but wives have been married more than once; n=1
rm(KenyaDHS1998_couples)
rm(Nyanza1998)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,CurrentSinglePartnershipsF1998$v511),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,(CurrentSinglePartnershipsF1998$v511 + CurrentSinglePartnershipsF1998$mv012 - CurrentSinglePartnershipsF1998$v012)),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsF1998$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsF1998$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsF1998$v012 - CurrentSinglePartnershipsF1998$v511)),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsF1998$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsF1998$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsF1998$mv002)
)

rm(CurrentSinglePartnershipsF1998)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,(CurrentSinglePartnershipsM1998$mv511 + CurrentSinglePartnershipsM1998$v012 - CurrentSinglePartnershipsM1998$mv012)),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,CurrentSinglePartnershipsM1998$mv511),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsM1998$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsM1998$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsM1998$v012 - (CurrentSinglePartnershipsM1998$mv511 + CurrentSinglePartnershipsM1998$v012 - CurrentSinglePartnershipsM1998$mv012))),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsM1998$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsM1998$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsM1998$mv002)
)

rm(CurrentSinglePartnershipsM1998)


KenyaDHS1993_couples  <- read.dta13('KE_1993_DHS_microdata/kecr32dt/KECR32FL.DTA')
Nyanza1993 <- subset(KenyaDHS1993_couples, v024=="nyanza")
# Nyanza1993 contains 188 couples
CurrentSinglePartnershipsF1993 <- subset(Nyanza1993, v503=="once")
# currently married women who have only been married once; n=176
CurrentSinglePartnershipsM1993 <- subset(Nyanza1993, mv503=="once" & v503!="once")
# currently married men who have only been married once, but wives have been married more than once; n=3
rm(KenyaDHS1993_couples)
rm(Nyanza1993)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,CurrentSinglePartnershipsF1993$v511),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,(CurrentSinglePartnershipsF1993$v511 + CurrentSinglePartnershipsF1993$mv012 - CurrentSinglePartnershipsF1993$v012)),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsF1993$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsF1993$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsF1993$v012 - CurrentSinglePartnershipsF1993$v511)),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsF1993$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsF1993$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsF1993$mv002)
)

rm(CurrentSinglePartnershipsF1993)

CSP_data <- data.frame("F_ageAtMarriage"   = c(CSP_data$F_ageAtMarriage,(CurrentSinglePartnershipsM1993$mv511 + CurrentSinglePartnershipsM1993$v012 - CurrentSinglePartnershipsM1993$mv012)),
                       "M_ageAtMarriage"   = c(CSP_data$M_ageAtMarriage,CurrentSinglePartnershipsM1993$mv511),
                       "F_currentAge"      = c(CSP_data$F_currentAge,CurrentSinglePartnershipsM1993$v012),
                       "M_currentAge"      = c(CSP_data$M_currentAge,CurrentSinglePartnershipsM1993$mv012),
                       "marriageDuration"  = c(CSP_data$marriageDuration,(CurrentSinglePartnershipsM1993$v012 - (CurrentSinglePartnershipsM1993$mv511 + CurrentSinglePartnershipsM1993$v012 - CurrentSinglePartnershipsM1993$mv012))),
                       "sample.weight"     = c(CSP_data$sample.weight,CurrentSinglePartnershipsM1993$mv005/1000000),
                       "cluster"           = c(CSP_data$cluster,CurrentSinglePartnershipsM1993$mv021),
                       "household"         = c(CSP_data$household,CurrentSinglePartnershipsM1993$mv002)
)

rm(CurrentSinglePartnershipsM1993)


# load('.Rdata')


# create survey data frame

CSP_design <- svydesign(ids = ~cluster + household, weights = ~sample.weight, data = CSP_data, variables=NULL)
# create survey design object

cont_tbl <- svytable(~F_ageAtMarriage+M_ageAtMarriage, CSP_design, Ntotal = 1, round = FALSE)
# create contingency table using survey weights

cont_tbl_marrDur <- svytable(~F_currentAge+marriageDuration, CSP_design, Ntotal = 1, round = FALSE)

plot(cont_tbl)
plot(cont_tbl_marrDur)

fwrite(data.frame(cont_tbl), file = "MFAgeAtMarriageNyanza.csv",row.names=TRUE)
fwrite(data.frame(cont_tbl_marrDur), file = "MarriageDurationNyanza.csv",row.names=TRUE)

# CSP_data 1448 observations


