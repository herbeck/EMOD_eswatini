# Kenya Couples Recode

library(foreign)
library(survey)
library(dplyr)

# setting up the working directory
homedir<-'C:/Users/kkripke/Dropbox/OPTIONS/ZimPrEP-LSHTM/Kenya/DHS marriage analysis/KE_2014_DHS_microdata/kecr70dt'
setwd(homedir)

# reading in the data (note: if stata version is Stata 13 or newer, there is an alternative command to read in data: readstata13)
df <- read.dta("KECR70FL.DTA")

# setting up the sample weights and survey design
df$sampleweights <- df$v005/1000000
design <- svydesign(ids=~v021, strata=~v022, weights=~sampleweights, data=df)


# if you wanted the national average number of wives among men in the couples data set
svymean(df$mv035,  design, na.rm=TRUE)

# if you wanted them by county
svyby(~mv035, by=~sregion,
      design=design,
      FUN=svymean,
      na.rm=TRUE,
      weights=~sampleweights,
      data=df)

# if you wanted the same numbers as above, stored in a data frame (I will sometimes do this and then save the data to excel)
output.df <- svyby(~mv035, by=~sregion,
                   design=design,
                   FUN=svymean,
                   na.rm=TRUE,
                   weights=~sampleweights,
                   data=df)

# if you wanted to create individual data frames for each county (you could probably write a loop to do this faster)
levels(df$sregion)
nairobi      <- filter(df, sregion=="nairobi")
nyandarua    <- filter(df, sregion=="nyandarua")
nyeri        <- filter(df, sregion=="nyeri")
kirinyaga    <- filter(df, sregion=="kirinyaga")
muranga      <- filter(df, sregion=="muranga")
kiambu       <- filter(df, sregion=="kiambu")
mombasa      <- filter(df, sregion=="mombasa")
kwale        <- filter(df, sregion=="kwale")
kilifi      <- filter(df, sregion=="kilifi")
tana_river   <- filter(df, sregion=="tana river")
lamu         <- filter(df, sregion=="lamu")
taita_taveta <- filter(df, sregion=="taita taveta")
marsabit     <- filter(df, sregion=="marsabit")
isiolo       <- filter(df, sregion=="isiolo")
meru         <- filter(df, sregion=="meru")
tharaka      <- filter(df, sregion=="tharaka")
embu         <- filter(df, sregion=="embu")
kitui       <- filter(df, sregion=="kitui")
machakos     <- filter(df, sregion=="machakos")
makueni     <- filter(df, sregion=="makueni")
garissa      <- filter(df, sregion=="garissa")
wajir        <- filter(df, sregion=="wajir")
mandera     <- filter(df, sregion=="mandera")
siaya        <- filter(df, sregion=="siaya")
kisumu       <- filter(df, sregion=="kisumu")
migori       <- filter(df, sregion=="migori")
homa_bay    <- filter(df, sregion=="homa bay")
kisii        <- filter(df, sregion=="kisii")
nyamira      <- filter(df, sregion=="nyamira")
turkana      <- filter(df, sregion=="turkana")
west_pokot  <- filter(df, sregion=="west pokot")
samburu      <- filter(df, sregion=="samburu")
trans_nzoia  <- filter(df, sregion=="trans-nzoia")
baringo      <- filter(df, sregion=="baringo")
uasin_gishu  <- filter(df, sregion=="uasin gishu")
elgeyo_marak<- filter(df, sregion=="elgeyo marak")
nandi        <- filter(df, sregion=="nandi")
laikipia     <- filter(df, sregion=="laikipia")
nakuru       <- filter(df, sregion=="nakuru")
narok        <- filter(df, sregion=="narok")
kajiado      <- filter(df, sregion=="kajiado")
kericho      <- filter(df, sregion=="kericho")
bomet        <- filter(df, sregion=="bomet")
kakamega     <- filter(df, sregion=="kakamega")
vihiga      <- filter(df, sregion=="vihiga")
bungoma      <- filter(df, sregion=="bungoma")
busia  <- filter(df, sregion=="busia")
