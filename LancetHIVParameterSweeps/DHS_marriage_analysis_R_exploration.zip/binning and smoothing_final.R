# This script takes the output from DHSanalyzeNyanza2_AtMarriage.R, 
# which produces a .CSV file with a contingency table of unbinned frequencies of age at "marriage"
# (or cohabitation, depending on how defined in DHS), with male ages in the columns and female ages in the rows
# and converts it into two-year age bins, then applies a Gaussian smoothing function to the data


rm(list=ls(all=TRUE)) 
library(data.table)
library(AtmRay)
library(mvtnorm)


#set working directory
homedir<-'C:/Users/kkripke/Dropbox/OPTIONS/ZimPrEP-LSHTM/Kenya/DHS marriage analysis'
setwd(homedir)

#load file
inc_1st_marriages_raw <-read.csv("MFAgeAtMarriage_age7thru54_padded_Mcol_Frow.csv", stringsAsFactors=FALSE)
# file must have an even number of age bins in both rows and columns, starting at age 7
# input file is a contingency table of frequencies of age at "marriage" 
# (or cohabitation, depending on how defined in DHS), with male ages in the columns and female ages in the rows

#set data frame row names to values in 1st column - column names are already 1st row plus the letter "X"
row_names <- inc_1st_marriages_raw[,1]
row_names

inc_1st_marriages_raw <- inc_1st_marriages_raw[,2:ncol(inc_1st_marriages_raw)]

row.names(inc_1st_marriages_raw) <- row_names
rownames(inc_1st_marriages_raw)
inc_1st_marriages_raw


starting_age_M <- 7
starting_age_F <- 7

num_agesM <- length(inc_1st_marriages_raw)
num_agesF <- length(row_names)

# group 1-year categories into 2-year categories
num_groups_from_DHSdata <- (num_agesM)/2

inc_1st_marriages_2yr_bins <- data.frame(matrix(NA, nrow = num_groups_from_DHSdata, ncol = num_groups_from_DHSdata))

for(F_iter in 1:num_groups_from_DHSdata){
  for(M_iter in 1:num_groups_from_DHSdata){
    inc_1st_marriages_2yr_bins[F_iter, M_iter] <- 
    inc_1st_marriages_raw[2*F_iter-1, 2*M_iter-1] +
    inc_1st_marriages_raw[2*F_iter-1, 2*M_iter] + 
    inc_1st_marriages_raw[2*F_iter,   2*M_iter-1] +
    inc_1st_marriages_raw[2*F_iter,   2*M_iter]
  }
}

# fill in NAs

inc_1st_marriages_2yr_bins[(num_agesF/2 + 1):(num_agesM/2),] <- 0

# pad up data up to the age at which we want to stratify partner age
# preference. anyone older than the last bin edge will be grouped into one
# giant bin with equal preference for anyone over that age, e.g., 55+
  
pad_up_to_age <- 55
last_available_age_of_data <- starting_age_M + num_agesM - 2
number_of_bins_to_pad <- (pad_up_to_age - last_available_age_of_data)/2

# pad DHS data with zeros for additional age groups where questionnaire didn't reach
inc_1st_marriages_2yr_bins <- rbind(inc_1st_marriages_2yr_bins,data.frame(matrix(0,nrow = number_of_bins_to_pad,ncol = ncol(inc_1st_marriages_2yr_bins))))

padcolumn <- data.frame(matrix(0.000,nrow = nrow(inc_1st_marriages_2yr_bins), ncol = number_of_bins_to_pad))
colnames(padcolumn) <- paste("X",as.character(seq(ncol(inc_1st_marriages_2yr_bins)+1, ncol(inc_1st_marriages_2yr_bins)+number_of_bins_to_pad, by = 1)),sep = "")
inc_1st_marriages_2yr_bins <- cbind(inc_1st_marriages_2yr_bins,padcolumn)

colnames(inc_1st_marriages_2yr_bins) <- seq(from = starting_age_M, to = pad_up_to_age, by = 2)
rownames(inc_1st_marriages_2yr_bins) <- seq(from = starting_age_F, to = pad_up_to_age, by = 2)

# smooth out noise:

# create filter

mu <- c(0,0)
Sigma <- matrix(data = c(0.03,0,0,0.03), nrow = 2, ncol = 2)
x <- seq(from = -1, to = 1, by = .2)
# x <- seq(from = -1, to = 1, by = .5)
mgrid <- meshgrid(x,x)
X1 <- data.frame(mgrid["x"])
X2 <- data.frame(mgrid["y"])
iter <- length(x)
xfilter <- matrix(NA, nrow = iter*iter, ncol = 2)
for(X1_iter in 1:iter){
  for(X2_iter in 1:iter){
    xfilter[X1_iter+iter*(X2_iter-1),1] <- X1[X1_iter,X2_iter]
    xfilter[X1_iter+iter*(X2_iter-1),2] <- X2[X1_iter,X2_iter]
  }
}

colnames(xfilter) <- c("X1","X2")

blur_2yr_filter <- dmvnorm(xfilter,mu,Sigma)
blur_2yr_filter2D <- matrix(NA, nrow = iter, ncol = iter)
for(X1_iter in 1:iter){
  for(X2_iter in 1:iter){
    blur_2yr_filter2D[X1_iter,X2_iter] <- blur_2yr_filter[X1_iter+(X2_iter-1) * iter]
  }
}

# apply filter to data 
# got this from function from https://stackoverflow.com/questions/36748442/implementing-the-matlab-filter2-function-in-r
# needed to make one correction to code

filter2D <- function(img, window) {
  # Algorithm for 2D Correlation, replaces matlab "filter2" function
  filter_center_index_y <- median(1:dim(window)[1])
  filter_max_index_y <- dim(window)[1]
  filter_center_index_x <- median(1:dim(window)[2])
  filter_max_index_x <- dim(window)[2]
  
  # For each position in the picture, 2D correlation is done by 
  # calculating a score for all overlapping values within the two matrices
  x_min <- 1
  x_max <- dim(img)[2]
  y_min <- 1
  y_max <- dim(img)[1]
  
  df <- NULL
  for (x_val in c(x_min:x_max)){
    for (y_val in c(y_min:y_max)){
      # Distance from cell
      img_dist_left <- x_val-1
      img_dist_right <- x_max-x_val
      img_dist_up <- y_val-1
      img_dist_down <- y_max-y_val
      
      # Overlapping filter cells
      filter_x_start <- filter_center_index_x-img_dist_left
      if (filter_x_start < 1) {
        filter_x_start <- 1
      }
      filter_x_end <- filter_center_index_x+img_dist_right
      if (filter_x_end > filter_max_index_x) {
        filter_x_end <- filter_max_index_x
      }
      filter_y_start <- filter_center_index_y-img_dist_up
      if (filter_y_start < 1) {
        filter_y_start <- 1
      }
      filter_y_end <- filter_center_index_y+img_dist_down
      if (filter_y_end > filter_max_index_y) {
        filter_y_end <- filter_max_index_y
      }
      
      # Part of filter that overlaps
      filter_overlap_matrix <- window[filter_y_start:filter_y_end, filter_x_start:filter_x_end]
      
      # Overlapped image cells
      image_x_start <- x_val-filter_center_index_x+1
      if (image_x_start < 1) {
        image_x_start <- 1
      }
      image_x_end <- x_val+filter_max_index_x-filter_center_index_x
      if (image_x_end > x_max) {
        image_x_end <- x_max
      }
      image_y_start <- y_val-filter_center_index_y+1
      if (image_y_start < 1) {
        image_y_start <- 1
      }
      image_y_end <- y_val+filter_max_index_y-filter_center_index_y
      if (image_y_end > y_max) {
        image_y_end <- y_max
      }
      
      # Part of image that is overlapped
      image_overlap_matrix <- img[image_y_start:image_y_end, image_x_start:image_x_end]
      
      # Calculating the cell value
      cell_value <- sum(filter_overlap_matrix*image_overlap_matrix)
      df = rbind(df,data.frame(x_val,y_val, cell_value))
    }
  }
  
  # Axis labels
  x_axis <- c(x_min:x_max)
  y_axis <- c(y_min:y_max)
  
  # Populating matrix
  filter_matrix <- matrix(df[,3], nrow = x_max, ncol = y_max, dimnames = list(x_axis, y_axis))
  
  return(filter_matrix)
}

inc_1st_marriages_smoothed <- filter2D(inc_1st_marriages_2yr_bins,blur_2yr_filter2D)

#supply column and row names
colnames(inc_1st_marriages_smoothed) <- seq(from = starting_age_M, to = pad_up_to_age, by = 2)
rownames(inc_1st_marriages_smoothed) <- seq(from = starting_age_F, to = pad_up_to_age, by = 2)

write.csv(inc_1st_marriages_2yr_bins,file = "inc_1st_marriages_2yr_bins.csv")
write.csv(inc_1st_marriages_smoothed,file = "inc_1st_marriages_smoothed.csv")
