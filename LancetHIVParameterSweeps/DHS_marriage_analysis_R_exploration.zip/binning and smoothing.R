library(data.table)



#set working directory
homedir<-'C:/Users/kkripke/Dropbox/OPTIONS/ZimPrEP-LSHTM/Kenya/DHS marriage analysis'
setwd(homedir)

df <-as.data.table(read.csv("MFAgeAtMarriage_age6thru52_padded_Mcol_Frow.csv"))

row_names <- df[,1]
row_names

df <- df[,2:ncol(df)]
# row.names(df) <- as.vector(row_names[1:nrow(row_names)])
# haven't figured out how to assign row names to df
df

# Print out `df`
print(df)